@extends('layouts.app')
@section('header')
<link rel="stylesheet" href="{{ asset('/storage/css/about.css') }}" />
@endsection
@section('content')
<div class="aboutContainer">
    <div>
        <div class="title">MineHighVN</div>
        <div class="description">Là một thằng Wibu rẻ rách, Deadline sát đít rồi vẫn lấy lí do học Laravel, Tìm hiểu thị trường, tối ưu SEO, viết báo cáo,... để ngồi code web này và xem Anime</div>
    </div>
</div>
@endsection