<?php $__env->startSection('header'); ?>
<link rel="stylesheet" href="<?php echo e(asset('/storage/css/post.css')); ?>"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php if(isset($post)): ?>
<div class="postContainer">
    <h1><?php echo e($post->title); ?></h1>
    
    <div>
        <div class="postInformation">
            <div class="author"><?php echo e($post->author->username); ?></div>
            <div class="createdAt"><?php echo e($post->created_at); ?></div>
        </div>
        
        <div class="content">
            <?php echo nl2br(htmlspecialchars($post->content)); ?>

        </div>
    </div>
    
    <?php if(isset($user)): ?>
        <h3>Hãy để lại bình luận</h3>
        <?php if(!empty($errors->all())): ?>
            <div class="message error">
                <?php echo e($errors->all()[0]); ?>

            </div>
        <?php endif; ?>
        <div>
            <form method="POST" class="commentContainer">
                <?php echo csrf_field(); ?>
                <textarea name="content" class="commentBox" placeholder="Bình luận dưới tên <?php echo e($user->username); ?>"></textarea>
                <div class="sendComment">
                    <button>Gửi</button>
                </div>
            </form>
        </div>
    <?php else: ?>
        <div class="message error">
            Bạn cần phải đăng nhập để bình luận
        </div>
    <?php endif; ?>
    <h3>Bình luận</h3>
    <div class="userComments">
        <?php $__currentLoopData = $post->comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div>
                <div class="commentInformation">
                    <div class="author"><?php echo e($comment->author->username); ?></div>
                    <div class="createdAt"><?php echo e($comment->created_at); ?></div>
                </div>
                <div class="content"><?php echo e($comment->content); ?></div>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php else: ?>

<div class="message error">Không tìm thấy bài viết</div>

<?php endif; ?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/minehighvn/Documents/Web/LaravelTutorial/resources/views/blog/showPost.blade.php ENDPATH**/ ?>