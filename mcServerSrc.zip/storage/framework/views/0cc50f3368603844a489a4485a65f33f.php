<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, user-scalable=0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css" integrity="sha512-z3gLpd7yknf1YoNbCzqRKc4qyor8gaKU1qmn+CShxbuBusANI9QpRohGBreCFkKxLhei6S9CQXFEbbKuqLg0DA==" crossorigin="anonymous" referrerpolicy="no-referrer" />
    <link rel="stylesheet" href="<?php echo e(asset('/storage/css/index.css')); ?>"/>
    <link rel="stylesheet" href="<?php echo e(asset('/storage/css/navbar.css')); ?>" />
    <link rel="stylesheet" href="<?php echo e(asset('/storage/css/footer.css')); ?>" />
    <link rel="icon" href="<?php echo e(asset("/storage/image/logo.png")); ?>" />

    <script src="<?php echo e(asset('/storage/javascript/navbar.js')); ?>"></script>

    <?php echo $__env->yieldContent('header'); ?>

    <title><?php echo e(env('SERVER_TITLE')); ?></title>
</head>
<body>
    <div class="container">
        <?php echo $__env->make('layouts.header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <div class="body">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
    <?php echo $__env->make('layouts.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</body>
</html><?php /**PATH /home/minehighvn/Documents/Web/LaravelTutorial/resources/views/layouts/app.blade.php ENDPATH**/ ?>