<?php $__env->startSection('content'); ?>
<div><i class="fa-solid fa-user"></i><input value="<?php echo e(old('username')); ?>" placeholder="Tên đăng nhập" name='username'/></div>
<div><i class="fa-solid fa-lock"></i><input placeholder="Mật khẩu" name='password' type="password"/></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.auth.auth', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/minehighvn/Documents/Web/MinecraftServer/resources/views/auth/login.blade.php ENDPATH**/ ?>