<?php $__env->startSection('header'); ?>
<link rel="stylesheet" href="<?php echo e(asset('/storage/css/blog.css')); ?>"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<?php if($postPermission): ?>
    <div class="createPostBox">
        <a class="createPostRedirect" href="/admin/blog/create">Xin chào bạn! Hãy viết gì đi chứ!</a>
    </div>
<?php endif; ?>
<div class="blogContainer">
    <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <a href="<?php echo e(URL("/blog/{$post->id}")); ?>">
            <div class="title"><h1><?php echo e($post->title); ?></h1></div>
            <div class="authorWCreatedAt">
                <div class="author"><span><i class="fa-regular fa-user"></i> Tác giả: <?php echo e($post->author->username); ?></span></div>
                <div class="createdAt">Thời gian <?php echo e($post->created_at); ?></div>
            </div>
            <div class="description"><span><?php echo nl2br(htmlspecialchars(substr($post->content, 0, 100))); ?> <?php if(strlen($post->content) > 100): ?> <b>...Đọc thêm</b> <?php endif; ?></span></div>
        </a>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/minehighvn/Documents/Web/LaravelTutorial/resources/views/blog/blog.blade.php ENDPATH**/ ?>