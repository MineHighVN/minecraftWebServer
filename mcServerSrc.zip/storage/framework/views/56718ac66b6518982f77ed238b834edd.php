<div class="footerParent">
    <footer>
        <div>
            <h3>Thông tin</h3>
            <div>
                Trường này là thông tin về server của bạn
            </div>
        </div>
        <div>
            <h3>Menu</h3>
            <div>
                <a href='/'>Trang chủ</a>
                <a href='/shop'>Cửa hàng</a>
                <a href='/login'>Đăng nhập</a>
                <a href='/register'>Đăng ký</a>
            </div>
        </div>
        <div>
            <h3>Mạng xã hội</h3>
            <div class="socialNetwork">
                <a href="#"><i class="fa-brands fa-facebook"></i> Facebook</a>
                <a href="#"><i class="fa-brands fa-youtube"></i> YouTube</a>
                <a href="#"><i class="fa-brands fa-discord"></i> Discord</a>
            </div>
        </div>
        <div>
            <h3>Liên hệ</h3>
            <div>
                Nơi đây chứa thôi tin liên hệ của bạn
            </div>
        </div>
    </footer>
</div><?php /**PATH /home/minehighvn/Documents/Web/MinecraftServer/resources/views/layouts/footer.blade.php ENDPATH**/ ?>