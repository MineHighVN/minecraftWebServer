<?php $__env->startSection('header'); ?>
<link rel="stylesheet" href="<?php echo e(asset('/storage/css/profile.css')); ?>"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<?php if($user): ?>
<div class="profileHeader">
    <h1 class="username"><?php echo e($user->username); ?></h1>
    <div class="email"><?php echo e($user->email); ?></div>
</div>
<div class="profileMessage">
    <?php if($errors->any()): ?> <div class="message error"><?php echo e($errors->first()); ?></div> <?php endif; ?>
    <?php if(Session::get('success')): ?> <div class="message success"><?php echo e(Session::get('success')); ?></div> <?php endif; ?>
</div>
<div class="profileContainer">
        <div class="mainProfile">
            <div class="contentWDescription">
                <div class="description">
                    <div>
                        <h3>Giới thiệu <?php if(!$other): ?> bản thân <?php endif; ?></h3>
                        <div>
                            <span><?php echo e($user->description == '' ? 'Không có mô tả' : $user->description); ?></span>
                        </div>
                    </div>
                    <div>
                        <h3>Thông tin khác</h3>
                        <div>
                            <p>Rank: <?php echo e($user->getRank?->displayRank); ?></p>
                            <p>Độ ưu tiên: <?php echo e($user->weight); ?></p>
                            <p>Ngày đăng ký: <?php echo e($user->created_at); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <?php if($edit): ?>
                <div class="contentWDescription">
                    <div class="description">
                        <?php if(!$other): ?>
                            <div>
                                <h3>Cài đặt</h3>
                                <div class="settings">
                                    <form method="POST" action="/logout">
                                        <?php echo csrf_field(); ?>
                                        <button>Đăng xuất</button>
                                    </form>
                                </div>
                            </div>
                        <?php endif; ?>
                        <div>
                            <h3>Các quyền của <?php if($other): ?> <?php echo e($user->username); ?> <?php else: ?> bạn <?php endif; ?></h3>
                            <div>
                                <?php if($user->getRank?->permissions->count()): ?>
                                    <?php $__currentLoopData = $user->getRank->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permissions): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <p><?php echo e($permissions->displayName); ?></p>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                <?php else: ?>
                                    <p><?php echo e($other ? $user->username : "Bạn"); ?> không có quyền gì</p>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>
                </div>
            <?php endif; ?>
        </div>
        <?php if($edit): ?>
            <div class="profileEdit">
                <h3>Chỉnh sửa trang cá nhân</h3>
                <div class="profileEditBody">
                    <form method="POST" action="<?php echo e(URL("/user/{$user->username}/update/")); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="editForm">
                            <div>
                                <div>Email</div>
                                <div><input value="<?php echo e($user->email); ?>" name="email" placeholder="Email"/></div>
                            </div>
                            <div>
                                <div>Giới thiệu bản thân</div>
                                <div><textarea name="description" placeholder="Giới thiểu bản thân"><?php echo e($user->description); ?></textarea></div>
                            </div>
                        </div>
                        <div>
                            <button class="btn btn-success">Cập nhật</button>
                        </div>
                    </form>
                </div>
                <?php if($admin): ?>
                    <h3>Thay đổi người dùng (Admin)</h3>
                    <form method="POST" action="<?php echo e(URL("/admin/user/{$user->username}/update/")); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="editForm">
                            <div>
                                <div>Độ ưu tiên</div>
                                <div><input type="number" min="0" max="999" value="<?php echo e($user->weight); ?>" name="weight" placeholder="Độ ưu tiên"/></div>
                            </div>
                            <div>
                                <div>Rank</div>
                                <div>
                                    <select name="rank" title="Rank">
                                        <?php $__currentLoopData = $ranks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $rank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option <?php if($user->rank == $rank->id): ?> <?php if(true): echo 'selected'; endif; ?> <?php endif; ?> value="<?php echo e($rank->id); ?>"><?php echo e($rank->displayRank); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div>
                            <button class="btn btn-success">Cập nhật</button>
                        </div>
                    </form>
                <?php endif; ?>
            </div>
        <?php endif; ?>
    <?php else: ?>
        <div class="message error">Không tìm thấy người chơi này</div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/minehighvn/Documents/Web/MinecraftServer/resources/views/account/profile.blade.php ENDPATH**/ ?>