<?php $__env->startSection('header'); ?>
<link rel="stylesheet" href="<?php echo e(asset('/storage/css/blog.css')); ?>"/>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="createPostContainer">
    <h1 class="createPostTitle">Tạo bài viết mới</h1>
    
    <div class="errorBox">
        <?php if (! (empty($errors->all()))): ?>
            <div class="message error"><?php echo e($errors->all()[0]); ?></div>
        <?php endif; ?>
    </div>
    
    <div class="createPost">
        <form method="POST">
            <?php echo csrf_field(); ?>
            <input name="title" type="text" placeholder="Tiêu đề bài viết" />
            <textarea name="content" placeholder="Nội dung bài viết"></textarea>
            <button>Đăng bài</button>
        </form>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/minehighvn/Documents/Web/MinecraftServer/resources/views/blog/createPost.blade.php ENDPATH**/ ?>