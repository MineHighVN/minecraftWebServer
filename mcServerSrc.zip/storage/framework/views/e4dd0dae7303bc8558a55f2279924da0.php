<?php $__env->startSection('content'); ?>
<h2> Hello world</h2>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/minehighvn/Documents/Web/LaravelTutorial/resources/views/posts/index.blade.php ENDPATH**/ ?>