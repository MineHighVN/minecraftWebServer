<?php $__env->startSection('header'); ?>
<link rel="stylesheet" href="<?php echo e(URL('/storage/css/rank.css')); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="editRank">
    <div class="currentRank">
        Hiện đang chỉnh sửa rank: <b><?php echo e($rank->displayRank); ?></b>
    </div>
    <div class="rank">
        <div>
            <table>
                <thead>
                    <tr>
                        <th>STT</th>
                        <th>Permissions</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php for($i = 0; $i < $permissions->count(); $i++): ?>
                        <tr>
                            <td><?php echo e($i + 1); ?></td>
                            <td><?php echo e($permissions[$i]->displayName); ?></td>
                            <td>
                                <form method="POST" action="<?php echo e(URL("/admin/rank/$rank->id/toggle/" . $permissions[$i]->permId)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <button class="rankToggleBtn"><?php if(in_array($permissions[$i]->permId, $unusedPermissionIds)): ?>
                                        Thêm
                                    <?php else: ?>
                                        Xóa
                                    <?php endif; ?></button>
                                </form>
                            </td>
                        </tr>
                    <?php endfor; ?>
                </tbody>
            </table>
        </div>
    </div>
    <form method="POST" action="<?php echo e(URL("/admin/rank/$rank->id/delete/" )); ?>">
        <?php echo csrf_field(); ?>
        <button class="delete">Xóa rank này</button>
    </form>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/minehighvn/Documents/Web/LaravelTutorial/resources/views/admin/rank/rankEdit.blade.php ENDPATH**/ ?>