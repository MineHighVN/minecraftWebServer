<?php $__env->startSection('header'); ?>
<link rel="stylesheet" href="<?php echo e(asset("/storage/css/rules.css")); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="rulesContainer">
    <h1>Những luật hiện tại</h1>
    <div style="margin: 20px 0;">
        <?php if($errors->any()): ?> <div class="message error"><?php echo e($errors->first()); ?></div> <?php endif; ?>
        <?php if(Session::has('success')): ?> <div class="message success"><?php echo e(Session::get('success')); ?></div> <?php endif; ?>
    </div>
    <table class="table-default">
        <thead>
            <tr>
                <th>STT</th>
                <th>Nội dung</th>
                <th>Có hiệu lực vào</th>
                <?php if($admin): ?> <th>Action</th> <?php endif; ?>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $rules; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $rule): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($index + 1); ?></td>
                    <td><?php echo e($rule->content); ?></td>
                    <td><?php echo e($rule->created_at); ?></td>
                    <?php if($admin): ?>
                    <td>
                        <form method="POST" action="<?php echo e(URL("/admin/rules/{$rule->id}/delete")); ?>">
                            <?php echo csrf_field(); ?>
                            <button class="btn btn-success">Xóa luật này</button>
                        </form>
                    </td>
                    <?php endif; ?>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
    <?php if($admin): ?>
        <div class="rulesForm">
            <form method="POST" action="<?php echo e(URL("/admin/rules/add")); ?>">
                <?php echo csrf_field(); ?>
                <textarea placeholder="Nội dung điều luật" class="input-default" name="content"></textarea>
                <div>
                    <button class="btn btn-success">Thêm luật này</button>
                </div>
            </form>
        </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/minehighvn/Documents/Web/LaravelTutorial/resources/views/admin/rules/rules.blade.php ENDPATH**/ ?>