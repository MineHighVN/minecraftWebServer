<div class="navbarParent">
    <nav class="navbar">
        <div>
            <a href="<?php echo e(URL('/')); ?>"><div class="logo">
                <img src="<?php echo e(asset('/storage/image/logo.png')); ?>" alt="logo" />
            </div></a>
        </div>
        <div>
        </div>
        <ul>
            <div class="navbarHeader">
                <div class="title"><h3>Server Title</h3></div>
                <div class="close">X</div>
            </div>
            <li><a class='<?php echo e((isset($select) && $select == "home") ? 'active' : ''); ?>' href="<?php echo e(URL("/")); ?>">Trang chủ</a></li>
            <li><a class='<?php echo e((isset($select) && $select == "blog") ? 'active' : ''); ?>' href="<?php echo e(URL("/blog")); ?>">Blog</a></li>
            <li><a class='<?php echo e((isset($select) && $select == "rules") ? 'active' : ''); ?>' href="<?php echo e(URL("/rules")); ?>">Luật chung</a></li>
            <li><a class='<?php echo e((isset($select) && $select == "about") ? 'active' : ''); ?>' href="<?php echo e(URL("/about")); ?>">Về chúng tôi</a></li>
            <li><a class='<?php echo e((isset($select) && $select == "profile") ? 'active' : ''); ?>' href="<?php echo e(URL("/profile")); ?>">Tài khoản</a></li>
        </ul>
        <div class="overlay"></div>
        <i class="fa-solid fa-bars hamburger"></i>
    </nav>
</div>
<?php /**PATH /home/minehighvn/Documents/Web/LaravelTutorial/resources/views/layouts/header.blade.php ENDPATH**/ ?>