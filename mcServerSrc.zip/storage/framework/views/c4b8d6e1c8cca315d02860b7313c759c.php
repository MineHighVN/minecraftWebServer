<?php $__env->startSection('header'); ?>
<link rel="stylesheet" href="<?php echo e(URL('/storage/css/home.css')); ?>" />
<script>
    const serverIP = "<?php echo e(env('SERVER_IP')); ?>"
</script>
<script src="<?php echo e(asset('/storage/javascript/home.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="home">
    <?php if($permsCount): ?>
        <div class="adminPanel">
            <h3>ADMIN PANEL</h3>
            <div class="option">
                <a href="<?php echo e(URL('/admin/rank/')); ?>">Quản lí rank</a>
                <a href="<?php echo e(URL('/admin/blog/create')); ?>">Tạo bài viết</a>
                <a href="<?php echo e(URL('/rules')); ?>">Quản lí luật chung</a>
            </div>
        </div>
    <?php endif; ?>
    <div class="homeBody">
        <div class="serverInformation">
            
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/minehighvn/Documents/Web/LaravelTutorial/resources/views/home.blade.php ENDPATH**/ ?>