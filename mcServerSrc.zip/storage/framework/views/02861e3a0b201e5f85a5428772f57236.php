<?php $__env->startSection('header'); ?>
<link rel="stylesheet" href="<?php echo e(URL('/storage/css/rank.css')); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="rank">
    <div>
        <table>
            <thead>
                <tr>
                    <th>STT</th>
                    <th>Permissions ID</td>
                    <th>Permissions Name</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($permission->permId); ?></td>
                        <td><?php echo e($permission->displayName); ?></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
    <div>
        <table>
            <thead>
                <tr>
                    <th>STT</th>
                    <th>Rank</th>
                    <th>Permissions</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <?php $__currentLoopData = $ranks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $rank): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($index + 1); ?></td>
                        <td><?php echo e($rank->displayRank); ?></td>
                        <td class="permissions">
                            <?php $__currentLoopData = $rank->permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $permission): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div><?php echo e($permission->displayName); ?></div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </td>
                        <td class="linkEdit"><a href="<?php echo e(URL("/admin/rank/{$rank->id}")); ?>">Edit</a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
        </table>
    </div>
</div>


<div class="rankForm">
    <h3>Tạo rank mới</h3>
    <div>
        <form method="POST" action="/admin/rank/create">
            <?php echo csrf_field(); ?>
            <input name="rankname" placeholder="Tên rank" />
            <button>Tạo rank mới</button>
        </form>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/minehighvn/Documents/Web/MinecraftServer/resources/views/admin/rank/rank.blade.php ENDPATH**/ ?>