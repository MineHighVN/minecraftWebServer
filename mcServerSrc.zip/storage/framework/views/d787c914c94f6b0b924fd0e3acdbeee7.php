<?php $__env->startSection('header'); ?>
<link rel="stylesheet" href="<?php echo e(asset('/storage/css/about.css')); ?>" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="aboutContainer">
    <div>
        <div class="title">MineHighVN</div>
        <div class="description">Là một thằng Wibu rẻ rách, Deadline sát đít rồi vẫn lấy lí do học Laravel, Tìm hiểu thị trường, tối ưu SEO, viết báo cáo,... để ngồi code web này và xem Anime</div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/minehighvn/Documents/Web/LaravelTutorial/resources/views/about/about.blade.php ENDPATH**/ ?>